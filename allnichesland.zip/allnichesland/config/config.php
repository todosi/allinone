<?php  

$seo_url = 'robux-gen-free.orgfree.com';  
$seo_title = 'Free Robux Generator';  
$seo_description = 'Roblox Free Robux Generator';  
$seo_keywords = 'Free Robux, Get Free Robux, Earn Free Robux';  
$seokey = 'Free Robux, Get Free Robux, Earn Free Robux';  

$title = 'Robux FREE Geneartor';
$appgame = 'ROBLOX'; 
$rewards = 'ROBUX';  

$colorone = '#4b974b';  
$colortwo = '#66c466';  

$cpa_it = '1750972';	  
$cpa_key = '5dc52';	  

?>